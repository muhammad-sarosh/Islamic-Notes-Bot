"""Check physical page marker coverage; does not verify transcription accuracy."""
import argparse
import json
from pathlib import Path
import re


def parse_pages(spec):
    result = set()
    for item in spec.split(','):
        match = re.fullmatch(r'\s*(\d+)(?:-(\d+))?\s*', item)
        if not match:
            raise ValueError('Use physical page ranges such as 1-5,8,10-12')
        first, last = int(match[1]), int(match[2] or match[1])
        if first < 1 or last < first:
            raise ValueError('Page ranges must be positive and ascending')
        result.update(range(first, last + 1))
    return sorted(result)


def verify(text, expected):
    markers = list(re.finditer(r'^===== PAGE (\d+) =====[ \t]*\r?$', text, re.M))
    actual = [int(m[1]) for m in markers]
    empty = []
    for i, marker in enumerate(markers):
        end = markers[i + 1].start() if i + 1 < len(markers) else len(text)
        if not text[marker.end():end].strip():
            empty.append(int(marker[1]))
    valid = actual == expected and bool(markers) and not text[:markers[0].start()].strip()
    return {'coverage_ok': valid, 'expected': expected, 'actual': actual,
            'empty_pages_require_visual_confirmation': empty,
            'unreadable_markers': text.count('[UNREADABLE]'),
            'visual_accuracy_checked_by_script': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('text_file', type=Path)
    parser.add_argument('--pages', required=True)
    args = parser.parse_args()
    try:
        result = verify(args.text_file.read_text(encoding='utf-8-sig'), parse_pages(args.pages))
    except ValueError as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['coverage_ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
