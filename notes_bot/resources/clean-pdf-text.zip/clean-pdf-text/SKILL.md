---
name: clean-pdf-text
description: Transcribe Urdu/Arabic course PDFs into faithful, visually verified, page-marked UTF-8 text for RAG and semantic-search indexing. Use for cleaned PDF extraction, not summaries or rewritten content.
---

# Clean PDF Text

Produce a transcription/cleaned extraction, never a summary. Factual fidelity takes priority over stylistic polish. Never modify the original PDF. Keep raw extraction, page images, review notes, and final text in separate files.

## Inspect and report first

Resolve the source and requested physical pages (1-based); default to every page if no range is specified. Preserve printed page numbers separately from physical page markers.

Inspect with Python `pypdf`, checking each requested page for extractable text. Nonempty text alone does not establish usability: a page may contain only a watermark or page number, or corrupt glyphs. Identify mixed scanned/text pages. Compare representative rendered pages if necessary to establish usability. Before bulk extraction and visual verification, report:

- Whether an embedded/selectable text layer exists, including partial coverage and uncertainty about usability.
- The method: `pypdf` for usable embedded text; targeted OCR only where no usable text can be recovered.
- Physical pages being processed and the intended batch size.

For encrypted PDFs, obtain an authorized password when needed; do not bypass access restrictions. Use available Python runtimes and install missing dependencies only within permitted scope.

## Extract, render, and reconcile

Do not normalize, paraphrase, or "improve" Urdu wording. Preserve the exact printed wording wherever it can be determined from the page image. When uncertain about a character, inspect the rendered image again rather than guessing from linguistic context.

1. Use `pypdf.PdfReader` and `page.extract_text()` for usable embedded text. Save raw text per physical page, preserving it as evidence. Record extraction failures separately rather than silently treating them as blank pages.
2. Render every requested page using `pypdfium2.PdfDocument`, `document[index].render(scale=2)`, and the bitmap's `to_pil().save(...)`. Close bitmaps, pages, and documents after use. Scale 2 is 144 dpi; increase resolution or inspect crops for unclear small characters or diacritics.
3. Work in manageable batches, typically 3–10 pages depending on density. View every rendered page with image-viewing tools and compare it against extracted text. Do not infer visual agreement from extraction alone. The rendered printing is authoritative when it conflicts with the text layer.
4. Correct broken Urdu/Arabic character ordering, spacing, mistaken glyphs/words, disconnected runs, and paragraph/heading ordering only as supported by the image. Reconstruct logical reading order for RTL passages and mixed RTL/LTR text. Do not blindly reverse strings, words, or digits, or apply display-oriented bidi reshaping to indexing text.
5. Preserve wording, spelling, printed punctuation and diacritics, Arabic quotations, Qur'an verses, Hadith, citations, footnotes, printed page numbers, headings, numbered lists, and meaningful table/list relationships. Determine column and footnote order from layout; keep footnotes on their source page. Do not silently remove recurring headers or page numbers.
6. Rejoin typographic line wraps only when wording and meaningful structure remain intact. Do not paraphrase, summarize, modernize, translate, correct the author's grammar, expand abbreviations, or replace quotations from memory or another edition. Avoid broad normalization that merges distinct Arabic/Urdu letters or strips diacritics.
7. Use OCR only for pages/regions without usable embedded text, or specific portions that cannot otherwise be recovered. Prefer Urdu/Arabic language support. Visually verify OCR just as carefully. Record OCR pages/regions in separate review notes. Do not send PDFs to external OCR services without authorization.
8. If printing remains unreadable after higher-resolution review and available recovery methods, do not guess. Insert a localized `[UNREADABLE]` marker, retain readable surrounding text, and record the page/location in separate notes. Disclose incomplete recovery.

## Output and completion gate

Write one UTF-8 `.txt` file with exactly one marker per requested physical page, in source order:

```text
===== PAGE 1 =====
Faithful transcription of page 1

===== PAGE 2 =====
Faithful transcription of page 2
```

For subsets, use actual physical numbers (e.g. 7, 8), not numbering reset to 1. Include genuinely blank pages with their marker and no invented content. Keep processing commentary out of indexing text; record blank-page decisions and uncertainties separately.

Before finishing:

- Confirm every requested page was rendered, viewed, and transcribed exactly once. Check beginnings/endings, quotations, lists, and page boundaries against images. Never claim visual verification for pages not viewed.
- Run `python scripts/verify_pages.py CLEANED.txt --pages 1-10,12` using this skill's script path. This checks marker coverage/order and flags empty sections for visual confirmation; it does not prove transcription accuracy.
- Compare the source PDF's SHA-256 before and after processing to verify it was unchanged.
- Deliver the text file with a concise report of pages covered, methods, visual review status, and unresolved portions.

For large PDFs, save each reviewed batch before continuing, then assemble the final file and check the complete requested range. Do not substitute a chat summary or stop after a sample unless the user requested a sample.
